import {Server} from '../types/index'

export default function(id:number, servers: Server[]) : number 
{
    for(let i=0;i<servers.length; i++) 
    {
        if(servers[i].serverId === id)
        {
        return i;
        }
    }
    return -1;
}