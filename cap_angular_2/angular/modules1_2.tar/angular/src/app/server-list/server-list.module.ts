import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms'
import { ServerComponent } from './server/server.component';
import { ServerListComponent } from './server-list.component';
import { AddServerFormComponent } from './add-server-form/add-server-form.component';
import { CommonModule } from '@angular/common';
import { LoggingComponent } from './logging/logging.component';

@NgModule({
    declarations: [
        ServerComponent,
        AddServerFormComponent,
        ServerListComponent,
        LoggingComponent
    ],
    imports: [
        CommonModule, 
        FormsModule
    ],
    exports: [
        ServerListComponent
    ]
})
export class ServerListModule { }
