import { Component, Input, OnInit, Output,EventEmitter } from '@angular/core';
import { Log } from "../../../types/index";

@Component({
  selector: 'add-server-form',
  templateUrl: './add-server-form.component.html'
})
export class AddServerFormComponent implements OnInit {

  serverName: string ="";
  noServerCreated: boolean = false; 
  displaySuccess: boolean = false;
  @Input() serverSubmitted: any;
  @Output() emitLog: EventEmitter<Log> = new EventEmitter();
  @Input() onAddServer: any;

  ngOnInit(): void {
  }

  submitServer = ( ev:Event ) => 
  {
    ev.preventDefault();
    this.noServerCreated = true;
    this.displaySuccess = true;
    const newServer = this.serverSubmitted(this.serverName)
    const newLog = {
      date: new Date(),
      description: `[serverID:${newServer.serverId}] Server ${newServer.serverName} created.`
    }
    this.emitLog.emit(<Log>newLog);
    setTimeout(() => this.cleanAll(),1000)
  }

  cleanAll()
  {
    this.serverName=""
    this.displaySuccess=false;
  }

}
