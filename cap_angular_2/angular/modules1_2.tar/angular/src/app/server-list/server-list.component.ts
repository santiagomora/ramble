import { Component, OnInit } from '@angular/core';
import {Log, Server} from '../../types/index'
import {findById} from '../../helper/index'

const dummyServers = [
  {
    serverId:0,
    serverEnabled:true,
    serverName:"Server 1"
  },
  {
    serverId:1,
    serverEnabled:true,
    serverName:"Server 2"
  },
  {
    serverId:2,
    serverEnabled:true,
    serverName:"Server 3"
  }
]

@Component({
  // this works as a css selector 
  // we can write this as [app-server]
  // and angular would render it inside an html element that has the app-server property
  // like: <div app-server></div>
  // or a class by using .app-server like <div class="app-server"></div>
  // you cant use pseudo selectors
  selector: 'server-list',
  //templateUrl: './servers.component.html',
  // we can change tempalteURL to be an html string, this way we wouldnt need the 
  templateUrl:"./server-list.component.html",
  // './servers.component.html'. using the template key
  // either templateUrl or template must be present not both
  //styleUrls: ['./server-list.component.css'],
  //we can also use inline styling with the styles key
  // styles = ['h3{color:blue}','h4{color:gray}' ]
})
export class ServerListComponent implements OnInit {
  
  public servers : Server[]

  public logs: Log[] = [];

  ngOnInit(): void {
  }

  constructor()
  {
    this.servers = dummyServers
  }

  appendLog( log:Log )
  {
    this.logs = [...this.logs,log]
  }

  appendServer( server:Server )
  {
    this.servers = [...this.servers,server]
  }

  addServer = ( serverName: string ) : Server =>
  {
    const newServer = {
      serverName,
      serverId: this.servers.length,
      serverEnabled:true
    };
    this.appendServer(<Server>newServer)
    return newServer;
  }

  serverDelete = ( id: number ) : Server|null =>
  {
    let idPos,deletedServer,newLog;
    if ( (idPos=findById(id,this.servers))>=0 )
    {
      deletedServer = this.servers.splice(idPos,1).pop()
      return deletedServer;
    }
    return null;
  }
}
