import { Component, Input, EventEmitter, Output } from "@angular/core";
import { Log } from "../../../types/index";

@Component({
    selector: "server", 
    templateUrl:'./server.component.html'
})
export class ServerComponent 
{
    @Input() serverEnabled: boolean;
    @Input() serverId: number;
    @Input() serverName: string;
    @Input() onServerDelete: any;
    @Output() emitLog: EventEmitter<Log> = new EventEmitter();

    disableServer(e)
    {
        this.serverEnabled = false
        const newLog = {
          date: new Date(),
          description: `[serverID:${this.serverId}] Server ${this.serverName} was ${this.serverEnabled ? 'enabled' : 'disabled'}.`
        }
        this.emitLog.emit(<Log>newLog)
    }

    deleteServer(ev: Event)
    {
        ev.preventDefault();
        let newLog;
        const deletedServer = this.onServerDelete( +(<HTMLElement>ev.target).id );
        if (deletedServer)
        {
          newLog = {
            date: new Date(),
            description: `[serverID:${deletedServer.serverId}] Server ${deletedServer.serverName} was deleted.`
          }
          this.emitLog.emit(<Log>newLog)
        }
    }
}