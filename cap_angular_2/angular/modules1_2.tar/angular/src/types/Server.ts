type Server = {
    serverId: number;
    serverEnabled:boolean;
    serverName:string;
}

export default Server