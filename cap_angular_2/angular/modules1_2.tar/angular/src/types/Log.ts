type Log = {
    date: Date;
    description: string;
}
export default Log;